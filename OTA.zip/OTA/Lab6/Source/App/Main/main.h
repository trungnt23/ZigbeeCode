/*
 * main.h
 *
 *  Created on: Mar 15, 2022
 *      Author: TrungNT
 */

#ifndef SOURCE_APP_MAIN_MAIN_H_
#define SOURCE_APP_MAIN_MAIN_H_
typedef enum{
	POWER_ON_STATE,
	REPORT_STATE,
	IDLE_STATE,
	REBOOT_STATE
}systemState;

#endif /* SOURCE_APP_MAIN_MAIN_H_ */
